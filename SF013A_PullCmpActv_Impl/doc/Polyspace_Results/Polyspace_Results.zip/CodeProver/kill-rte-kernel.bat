@echo off
REM Host: SAGL611S562
"C:\Program Files\MATLAB\R2013b\polyspace\bin\terminate-polyspace-job.exe" 7476 "C:\component\SF013A_PullCmpActv_Impl\doc\Polyspace_Results\CodeProver\Polyspace_R2013b_Polyspace_06_23_2016-13h16.log" %1
RMDIR /S /Q "C:\Temp\Polyspace\1D34_1466702190" > NUL: 2>&1
