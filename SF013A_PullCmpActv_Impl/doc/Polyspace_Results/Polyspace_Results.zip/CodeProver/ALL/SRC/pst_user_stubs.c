/*
 *
 * This file and its contents are the property of The MathWorks, Inc.
 * 
 * This file contains confidential proprietary information.
 * The reproduction, distribution, utilization or the communication
 * of this file or any part thereof is strictly prohibited.
 * Offenders will be held liable for the payment of damages.
 *
 * Copyright 1999-2011 The MathWorks, Inc.
 *
 */
 
// Here is the list of functions which may need to be stubbed.
// 
// Here's how the stubber works: 
// 
// For each function in the list below, if you don't do anything
// it'll take the worst possible case, which is that the function 
// writes through the arguments as if they were pointers (even
// pointers cast to int).  
//
// External functions are assumed to not store their arguments
// in static / global data.
//
// External functions are also assumed to have no effect (read,
// write) on global variables.
//
// Any external functions which do not respect these two assumptions
// will need to be stubbed explicitely.
// 
// Here's an example:   int f(int)
// In the worst case, the stubber will assume that the function
// may behave something like this: 
// 
// 
//      int f(char *x)
//      {
//         strcpy(x, "the quick brown fox, etc.");
//
//         return &(x[2]);
//      }
// 
// This has a bad effect on both the analysis time, and on the
// the resulting selectivity rate.
// 
// 
// However, if you know that the function is in fact very tame,
// like this:
//      int f(char *x)
//      {
//        return strlen(x);
//      }
// 
// The stubber can provide a stub which will reflect this, and 
// have both fast analysis time and high selectivity.
// 
// I've provided below the pragma directives recognized by the
// verifier. All you need to to do is remove the initial //
// to activate the pragmas which are appropriate.
// 
// The NO_WRITE pragma indicates that the function does not
// write to or through its arguments.
// 
// The NO ESCAPE pragma indicates that the function does not
// allow access to the argument to escape through
// the return value.
// 
// In the first example above, neither pragmas apply.
// In the second example above, both pragmas apply.
//


#include "pst_user_stubs.h"


// Pragmas for function expf
//
// #pragma POLYSPACE_PURE "expf"
// #pragma POLYSPACE_CLEAN "expf"
// #pragma POLYSPACE_WORST "expf"
//
// __PST__FLOAT32 expf(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function fabsf
//
// #pragma POLYSPACE_PURE "fabsf"
// #pragma POLYSPACE_CLEAN "fabsf"
// #pragma POLYSPACE_WORST "fabsf"
//
// __PST__FLOAT32 fabsf(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_PullCmpActv_HwAg_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_PullCmpActv_HwAg_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_PullCmpActv_HwAg_Val"
// #pragma POLYSPACE_WORST "Rte_Read_PullCmpActv_HwAg_Val"
//
// __PST__UINT8 Rte_Read_PullCmpActv_HwAg_Val(__PST__g__16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_PullCmpActv_HwTq_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_PullCmpActv_HwTq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_PullCmpActv_HwTq_Val"
// #pragma POLYSPACE_WORST "Rte_Read_PullCmpActv_HwTq_Val"
//
// __PST__UINT8 Rte_Read_PullCmpActv_HwTq_Val(__PST__g__16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_PullCmpActv_HwVel_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_PullCmpActv_HwVel_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_PullCmpActv_HwVel_Val"
// #pragma POLYSPACE_WORST "Rte_Read_PullCmpActv_HwVel_Val"
//
// __PST__UINT8 Rte_Read_PullCmpActv_HwVel_Val(__PST__g__16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_PullCmpActv_PinionAgConf_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_PullCmpActv_PinionAgConf_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_PullCmpActv_PinionAgConf_Val"
// #pragma POLYSPACE_WORST "Rte_Read_PullCmpActv_PinionAgConf_Val"
//
// __PST__UINT8 Rte_Read_PullCmpActv_PinionAgConf_Val(__PST__g__16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_PullCmpActv_PullCmpActvDi_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_PullCmpActv_PullCmpActvDi_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_PullCmpActv_PullCmpActvDi_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_PullCmpActv_PullCmpActvDi_Logl"
//
// __PST__UINT8 Rte_Read_PullCmpActv_PullCmpActvDi_Logl(__PST__g__17 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_PullCmpActv_PullCmpCmdDi_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_PullCmpActv_PullCmpCmdDi_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_PullCmpActv_PullCmpCmdDi_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_PullCmpActv_PullCmpCmdDi_Logl"
//
// __PST__UINT8 Rte_Read_PullCmpActv_PullCmpCmdDi_Logl(__PST__g__17 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_PullCmpActv_PullCmpLrngDi_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_PullCmpActv_PullCmpLrngDi_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_PullCmpActv_PullCmpLrngDi_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_PullCmpActv_PullCmpLrngDi_Logl"
//
// __PST__UINT8 Rte_Read_PullCmpActv_PullCmpLrngDi_Logl(__PST__g__17 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_PullCmpActv_VehLatA_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_PullCmpActv_VehLatA_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_PullCmpActv_VehLatA_Val"
// #pragma POLYSPACE_WORST "Rte_Read_PullCmpActv_VehLatA_Val"
//
// __PST__UINT8 Rte_Read_PullCmpActv_VehLatA_Val(__PST__g__16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_PullCmpActv_VehSpd_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_PullCmpActv_VehSpd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_PullCmpActv_VehSpd_Val"
// #pragma POLYSPACE_WORST "Rte_Read_PullCmpActv_VehSpd_Val"
//
// __PST__UINT8 Rte_Read_PullCmpActv_VehSpd_Val(__PST__g__16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_PullCmpActv_VehSpdVld_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_PullCmpActv_VehSpdVld_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_PullCmpActv_VehSpdVld_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_PullCmpActv_VehSpdVld_Logl"
//
// __PST__UINT8 Rte_Read_PullCmpActv_VehSpdVld_Logl(__PST__g__17 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_PullCmpActv_VehYawRate_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_PullCmpActv_VehYawRate_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_PullCmpActv_VehYawRate_Val"
// #pragma POLYSPACE_WORST "Rte_Read_PullCmpActv_VehYawRate_Val"
//
// __PST__UINT8 Rte_Read_PullCmpActv_VehYawRate_Val(__PST__g__16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_PullCmpActv_PullCmpCmd_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_PullCmpActv_PullCmpCmd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_PullCmpActv_PullCmpCmd_Val"
// #pragma POLYSPACE_WORST "Rte_Write_PullCmpActv_PullCmpCmd_Val"
//
// __PST__UINT8 Rte_Write_PullCmpActv_PullCmpCmd_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_PullCmpActv_GetRefTmr100MicroSec32bit_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_PullCmpActv_GetRefTmr100MicroSec32bit_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_PullCmpActv_GetRefTmr100MicroSec32bit_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_PullCmpActv_GetRefTmr100MicroSec32bit_Oper"
//
// __PST__UINT8 Rte_Call_PullCmpActv_GetRefTmr100MicroSec32bit_Oper(__PST__g__32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_PullCmpActv_GetTiSpan100MicroSec32bit_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_PullCmpActv_GetTiSpan100MicroSec32bit_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_PullCmpActv_GetTiSpan100MicroSec32bit_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_PullCmpActv_GetTiSpan100MicroSec32bit_Oper"
//
// __PST__UINT8 Rte_Call_PullCmpActv_GetTiSpan100MicroSec32bit_Oper(__PST__UINT32 P_0, __PST__g__32 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_PullCmpActv_PullCmpLongTerm_SetRamBlockStatus
//
// #pragma POLYSPACE_PURE "Rte_Call_PullCmpActv_PullCmpLongTerm_SetRamBlockStatus"
// #pragma POLYSPACE_CLEAN "Rte_Call_PullCmpActv_PullCmpLongTerm_SetRamBlockStatus"
// #pragma POLYSPACE_WORST "Rte_Call_PullCmpActv_PullCmpLongTerm_SetRamBlockStatus"
//
// __PST__UINT8 Rte_Call_PullCmpActv_PullCmpLongTerm_SetRamBlockStatus(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PullCmpActv_PullCmpActvCmpLrnTiDecShoTerm_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PullCmpActv_PullCmpActvCmpLrnTiDecShoTerm_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PullCmpActv_PullCmpActvCmpLrnTiDecShoTerm_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PullCmpActv_PullCmpActvCmpLrnTiDecShoTerm_Val"
//
// __PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvCmpLrnTiDecShoTerm_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PullCmpActv_PullCmpActvCmpLrnTiIncShoTerm_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PullCmpActv_PullCmpActvCmpLrnTiIncShoTerm_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PullCmpActv_PullCmpActvCmpLrnTiIncShoTerm_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PullCmpActv_PullCmpActvCmpLrnTiIncShoTerm_Val"
//
// __PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvCmpLrnTiIncShoTerm_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PullCmpActv_PullCmpActvCmpLrnTiLongTerm_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PullCmpActv_PullCmpActvCmpLrnTiLongTerm_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PullCmpActv_PullCmpActvCmpLrnTiLongTerm_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PullCmpActv_PullCmpActvCmpLrnTiLongTerm_Val"
//
// __PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvCmpLrnTiLongTerm_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PullCmpActv_PullCmpActvCmpShoTermRstHwAgThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PullCmpActv_PullCmpActvCmpShoTermRstHwAgThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PullCmpActv_PullCmpActvCmpShoTermRstHwAgThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PullCmpActv_PullCmpActvCmpShoTermRstHwAgThd_Val"
//
// __PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvCmpShoTermRstHwAgThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PullCmpActv_PullCmpActvCmpShoTermRstHwTqThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PullCmpActv_PullCmpActvCmpShoTermRstHwTqThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PullCmpActv_PullCmpActvCmpShoTermRstHwTqThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PullCmpActv_PullCmpActvCmpShoTermRstHwTqThd_Val"
//
// __PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvCmpShoTermRstHwTqThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PullCmpActv_PullCmpActvCmpShoTermRstLatAThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PullCmpActv_PullCmpActvCmpShoTermRstLatAThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PullCmpActv_PullCmpActvCmpShoTermRstLatAThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PullCmpActv_PullCmpActvCmpShoTermRstLatAThd_Val"
//
// __PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvCmpShoTermRstLatAThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PullCmpActv_PullCmpActvCmpShoTermRstYawRateThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PullCmpActv_PullCmpActvCmpShoTermRstYawRateThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PullCmpActv_PullCmpActvCmpShoTermRstYawRateThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PullCmpActv_PullCmpActvCmpShoTermRstYawRateThd_Val"
//
// __PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvCmpShoTermRstYawRateThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PullCmpActv_PullCmpActvHwTqFilFrqLongTerm_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PullCmpActv_PullCmpActvHwTqFilFrqLongTerm_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PullCmpActv_PullCmpActvHwTqFilFrqLongTerm_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PullCmpActv_PullCmpActvHwTqFilFrqLongTerm_Val"
//
// __PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvHwTqFilFrqLongTerm_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PullCmpActv_PullCmpActvHwTqFilFrqLrngEna_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PullCmpActv_PullCmpActvHwTqFilFrqLrngEna_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PullCmpActv_PullCmpActvHwTqFilFrqLrngEna_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PullCmpActv_PullCmpActvHwTqFilFrqLrngEna_Val"
//
// __PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvHwTqFilFrqLrngEna_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PullCmpActv_PullCmpActvHwTqFilFrqShoTerm_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PullCmpActv_PullCmpActvHwTqFilFrqShoTerm_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PullCmpActv_PullCmpActvHwTqFilFrqShoTerm_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PullCmpActv_PullCmpActvHwTqFilFrqShoTerm_Val"
//
// __PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvHwTqFilFrqShoTerm_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PullCmpActv_PullCmpActvLongTermLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PullCmpActv_PullCmpActvLongTermLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PullCmpActv_PullCmpActvLongTermLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PullCmpActv_PullCmpActvLongTermLim_Val"
//
// __PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvLongTermLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PullCmpActv_PullCmpActvLrngEnaAgConfMinMgn_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaAgConfMinMgn_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaAgConfMinMgn_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaAgConfMinMgn_Val"
//
// __PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvLrngEnaAgConfMinMgn_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PullCmpActv_PullCmpActvLrngEnaHwAgMaxMgn_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaHwAgMaxMgn_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaHwAgMaxMgn_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaHwAgMaxMgn_Val"
//
// __PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvLrngEnaHwAgMaxMgn_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PullCmpActv_PullCmpActvLrngEnaHwTqMaxMgn_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaHwTqMaxMgn_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaHwTqMaxMgn_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaHwTqMaxMgn_Val"
//
// __PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvLrngEnaHwTqMaxMgn_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PullCmpActv_PullCmpActvLrngEnaHwVelMaxMgn_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaHwVelMaxMgn_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaHwVelMaxMgn_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaHwVelMaxMgn_Val"
//
// __PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvLrngEnaHwVelMaxMgn_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PullCmpActv_PullCmpActvLrngEnaLatAMaxMgn_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaLatAMaxMgn_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaLatAMaxMgn_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaLatAMaxMgn_Val"
//
// __PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvLrngEnaLatAMaxMgn_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PullCmpActv_PullCmpActvLrngEnaTiThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaTiThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaTiThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaTiThd_Val"
//
// __PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvLrngEnaTiThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PullCmpActv_PullCmpActvLrngEnaVehSpdMaxMgn_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaVehSpdMaxMgn_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaVehSpdMaxMgn_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaVehSpdMaxMgn_Val"
//
// __PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvLrngEnaVehSpdMaxMgn_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PullCmpActv_PullCmpActvLrngEnaVehSpdMinMgn_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaVehSpdMinMgn_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaVehSpdMinMgn_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaVehSpdMinMgn_Val"
//
// __PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvLrngEnaVehSpdMinMgn_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PullCmpActv_PullCmpActvLrngEnaVehSpdRateMaxMgn_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaVehSpdRateMaxMgn_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaVehSpdRateMaxMgn_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaVehSpdRateMaxMgn_Val"
//
// __PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvLrngEnaVehSpdRateMaxMgn_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PullCmpActv_PullCmpActvLrngEnaYawRateMaxMgn_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaYawRateMaxMgn_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaYawRateMaxMgn_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaYawRateMaxMgn_Val"
//
// __PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvLrngEnaYawRateMaxMgn_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PullCmpActv_PullCmpActvOpstSignTiShoTerm_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PullCmpActv_PullCmpActvOpstSignTiShoTerm_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PullCmpActv_PullCmpActvOpstSignTiShoTerm_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PullCmpActv_PullCmpActvOpstSignTiShoTerm_Val"
//
// __PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvOpstSignTiShoTerm_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PullCmpActv_PullCmpActvOutpMaxRate_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PullCmpActv_PullCmpActvOutpMaxRate_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PullCmpActv_PullCmpActvOutpMaxRate_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PullCmpActv_PullCmpActvOutpMaxRate_Val"
//
// __PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvOutpMaxRate_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PullCmpActv_PullCmpActvPullCmpShoTermLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PullCmpActv_PullCmpActvPullCmpShoTermLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PullCmpActv_PullCmpActvPullCmpShoTermLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PullCmpActv_PullCmpActvPullCmpShoTermLim_Val"
//
// __PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvPullCmpShoTermLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PullCmpActv_PullCmpActvPullCmpTotLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PullCmpActv_PullCmpActvPullCmpTotLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PullCmpActv_PullCmpActvPullCmpTotLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PullCmpActv_PullCmpActvPullCmpTotLim_Val"
//
// __PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvPullCmpTotLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PullCmpActv_PullCmpActvPullErrLimLongTerm_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PullCmpActv_PullCmpActvPullErrLimLongTerm_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PullCmpActv_PullCmpActvPullErrLimLongTerm_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PullCmpActv_PullCmpActvPullErrLimLongTerm_Val"
//
// __PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvPullErrLimLongTerm_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PullCmpActv_PullCmpActvPullErrMgnThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PullCmpActv_PullCmpActvPullErrMgnThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PullCmpActv_PullCmpActvPullErrMgnThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PullCmpActv_PullCmpActvPullErrMgnThd_Val"
//
// __PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvPullErrMgnThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PullCmpActv_PullCmpActvPullErrShoTermLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PullCmpActv_PullCmpActvPullErrShoTermLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PullCmpActv_PullCmpActvPullErrShoTermLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PullCmpActv_PullCmpActvPullErrShoTermLim_Val"
//
// __PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvPullErrShoTermLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PullCmpActv_PullCmpActvShoTermRampTi_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PullCmpActv_PullCmpActvShoTermRampTi_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PullCmpActv_PullCmpActvShoTermRampTi_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PullCmpActv_PullCmpActvShoTermRampTi_Val"
//
// __PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvShoTermRampTi_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PullCmpActv_PullCmpActvYawRateFilFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PullCmpActv_PullCmpActvYawRateFilFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PullCmpActv_PullCmpActvYawRateFilFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PullCmpActv_PullCmpActvYawRateFilFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvYawRateFilFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PullCmpActv_SysGlbPrmSysTqRat_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PullCmpActv_SysGlbPrmSysTqRat_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PullCmpActv_SysGlbPrmSysTqRat_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PullCmpActv_SysGlbPrmSysTqRat_Val"
//
// __PST__FLOAT32 Rte_Prm_PullCmpActv_SysGlbPrmSysTqRat_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PullCmpActv_PullCmpActvEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Prm_PullCmpActv_PullCmpActvEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PullCmpActv_PullCmpActvEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Prm_PullCmpActv_PullCmpActvEna_Logl"
//
// __PST__UINT8 Rte_Prm_PullCmpActv_PullCmpActvEna_Logl(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PullCmpActv_PullCmpActvVehSpdScaTblX_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_PullCmpActv_PullCmpActvVehSpdScaTblX_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PullCmpActv_PullCmpActvVehSpdScaTblX_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_PullCmpActv_PullCmpActvVehSpdScaTblX_Ary1D"
//
// __PST__g__44 Rte_Prm_PullCmpActv_PullCmpActvVehSpdScaTblX_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PullCmpActv_PullCmpActvVehSpdScaTblY_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_PullCmpActv_PullCmpActvVehSpdScaTblY_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PullCmpActv_PullCmpActvVehSpdScaTblY_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_PullCmpActv_PullCmpActvVehSpdScaTblY_Ary1D"
//
// __PST__g__44 Rte_Prm_PullCmpActv_PullCmpActvVehSpdScaTblY_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_IrvWrite_PullCmpActv_PullCmpActvInit1_RampDwnStepSize
//
// #pragma POLYSPACE_PURE "Rte_IrvWrite_PullCmpActv_PullCmpActvInit1_RampDwnStepSize"
// #pragma POLYSPACE_CLEAN "Rte_IrvWrite_PullCmpActv_PullCmpActvInit1_RampDwnStepSize"
// #pragma POLYSPACE_WORST "Rte_IrvWrite_PullCmpActv_PullCmpActvInit1_RampDwnStepSize"
//
// __PST__VOID Rte_IrvWrite_PullCmpActv_PullCmpActvInit1_RampDwnStepSize(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_IrvRead_PullCmpActv_PullCmpActvPer1_RampDwnStepSize
//
// #pragma POLYSPACE_PURE "Rte_IrvRead_PullCmpActv_PullCmpActvPer1_RampDwnStepSize"
// #pragma POLYSPACE_CLEAN "Rte_IrvRead_PullCmpActv_PullCmpActvPer1_RampDwnStepSize"
// #pragma POLYSPACE_WORST "Rte_IrvRead_PullCmpActv_PullCmpActvPer1_RampDwnStepSize"
//
// __PST__FLOAT32 Rte_IrvRead_PullCmpActv_PullCmpActvPer1_RampDwnStepSize(__PST__VOID)
// {
//    ...
// }


// Pragmas for function LnrIntrpn_u16_u16VariXu16VariY
//
// #pragma POLYSPACE_PURE "LnrIntrpn_u16_u16VariXu16VariY"
// #pragma POLYSPACE_CLEAN "LnrIntrpn_u16_u16VariXu16VariY"
// #pragma POLYSPACE_WORST "LnrIntrpn_u16_u16VariXu16VariY"
//
// __PST__UINT16 LnrIntrpn_u16_u16VariXu16VariY(__PST__g__44 P_0, __PST__g__44 P_1, __PST__UINT16 P_2, __PST__UINT16 P_3)
// {
//    ...
// }

