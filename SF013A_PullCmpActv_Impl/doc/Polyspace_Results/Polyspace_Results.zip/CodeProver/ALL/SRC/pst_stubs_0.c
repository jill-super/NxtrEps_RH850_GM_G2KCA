#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */


/* Definition of variables init procedures */


/* Definition of functions */

/*
 * expf
 */

#pragma POLYSPACE_POLYMORPHIC "expf"


__PST__FLOAT32 expf(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * fabsf
 */

#pragma POLYSPACE_POLYMORPHIC "fabsf"


__PST__FLOAT32 fabsf(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_PullCmpActv_HwAg_Val
 */


__PST__UINT8 Rte_Read_PullCmpActv_HwAg_Val(__PST__g__16 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_PullCmpActv_HwTq_Val
 */


__PST__UINT8 Rte_Read_PullCmpActv_HwTq_Val(__PST__g__16 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_PullCmpActv_HwVel_Val
 */


__PST__UINT8 Rte_Read_PullCmpActv_HwVel_Val(__PST__g__16 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_PullCmpActv_PinionAgConf_Val
 */


__PST__UINT8 Rte_Read_PullCmpActv_PinionAgConf_Val(__PST__g__16 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_PullCmpActv_PullCmpActvDi_Logl
 */


__PST__UINT8 Rte_Read_PullCmpActv_PullCmpActvDi_Logl(__PST__g__17 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_PullCmpActv_PullCmpCmdDi_Logl
 */


__PST__UINT8 Rte_Read_PullCmpActv_PullCmpCmdDi_Logl(__PST__g__17 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_PullCmpActv_PullCmpLrngDi_Logl
 */


__PST__UINT8 Rte_Read_PullCmpActv_PullCmpLrngDi_Logl(__PST__g__17 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_PullCmpActv_VehLatA_Val
 */


__PST__UINT8 Rte_Read_PullCmpActv_VehLatA_Val(__PST__g__16 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_PullCmpActv_VehSpd_Val
 */


__PST__UINT8 Rte_Read_PullCmpActv_VehSpd_Val(__PST__g__16 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_PullCmpActv_VehSpdVld_Logl
 */


__PST__UINT8 Rte_Read_PullCmpActv_VehSpdVld_Logl(__PST__g__17 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_PullCmpActv_VehYawRate_Val
 */


__PST__UINT8 Rte_Read_PullCmpActv_VehYawRate_Val(__PST__g__16 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_PullCmpActv_PullCmpCmd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_PullCmpActv_PullCmpCmd_Val"


__PST__UINT8 Rte_Write_PullCmpActv_PullCmpCmd_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_PullCmpActv_GetRefTmr100MicroSec32bit_Oper
 */


__PST__UINT8 Rte_Call_PullCmpActv_GetRefTmr100MicroSec32bit_Oper(__PST__g__32 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_8;
        }
        P_0[0] = pst_random_g_8;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_PullCmpActv_GetTiSpan100MicroSec32bit_Oper
 */


__PST__UINT8 Rte_Call_PullCmpActv_GetTiSpan100MicroSec32bit_Oper(__PST__UINT32 P_0, __PST__g__32 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    if (P_1 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_1[pst_random_int] = pst_random_g_8;
        }
        P_1[0] = pst_random_g_8;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_PullCmpActv_PullCmpLongTerm_SetRamBlockStatus
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Call_PullCmpActv_PullCmpLongTerm_SetRamBlockStatus"


__PST__UINT8 Rte_Call_PullCmpActv_PullCmpLongTerm_SetRamBlockStatus(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_PullCmpActv_PullCmpActvCmpLrnTiDecShoTerm_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_PullCmpActv_PullCmpActvCmpLrnTiDecShoTerm_Val"


__PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvCmpLrnTiDecShoTerm_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_PullCmpActv_PullCmpActvCmpLrnTiIncShoTerm_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_PullCmpActv_PullCmpActvCmpLrnTiIncShoTerm_Val"


__PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvCmpLrnTiIncShoTerm_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_PullCmpActv_PullCmpActvCmpLrnTiLongTerm_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_PullCmpActv_PullCmpActvCmpLrnTiLongTerm_Val"


__PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvCmpLrnTiLongTerm_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_PullCmpActv_PullCmpActvCmpShoTermRstHwAgThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_PullCmpActv_PullCmpActvCmpShoTermRstHwAgThd_Val"


__PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvCmpShoTermRstHwAgThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_PullCmpActv_PullCmpActvCmpShoTermRstHwTqThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_PullCmpActv_PullCmpActvCmpShoTermRstHwTqThd_Val"


__PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvCmpShoTermRstHwTqThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_PullCmpActv_PullCmpActvCmpShoTermRstLatAThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_PullCmpActv_PullCmpActvCmpShoTermRstLatAThd_Val"


__PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvCmpShoTermRstLatAThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_PullCmpActv_PullCmpActvCmpShoTermRstYawRateThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_PullCmpActv_PullCmpActvCmpShoTermRstYawRateThd_Val"


__PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvCmpShoTermRstYawRateThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_PullCmpActv_PullCmpActvHwTqFilFrqLongTerm_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_PullCmpActv_PullCmpActvHwTqFilFrqLongTerm_Val"


__PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvHwTqFilFrqLongTerm_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_PullCmpActv_PullCmpActvHwTqFilFrqLrngEna_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_PullCmpActv_PullCmpActvHwTqFilFrqLrngEna_Val"


__PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvHwTqFilFrqLrngEna_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_PullCmpActv_PullCmpActvHwTqFilFrqShoTerm_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_PullCmpActv_PullCmpActvHwTqFilFrqShoTerm_Val"


__PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvHwTqFilFrqShoTerm_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_PullCmpActv_PullCmpActvLongTermLim_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_PullCmpActv_PullCmpActvLongTermLim_Val"


__PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvLongTermLim_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_PullCmpActv_PullCmpActvLrngEnaAgConfMinMgn_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaAgConfMinMgn_Val"


__PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvLrngEnaAgConfMinMgn_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_PullCmpActv_PullCmpActvLrngEnaHwAgMaxMgn_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaHwAgMaxMgn_Val"


__PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvLrngEnaHwAgMaxMgn_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_PullCmpActv_PullCmpActvLrngEnaHwTqMaxMgn_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaHwTqMaxMgn_Val"


__PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvLrngEnaHwTqMaxMgn_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_PullCmpActv_PullCmpActvLrngEnaHwVelMaxMgn_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaHwVelMaxMgn_Val"


__PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvLrngEnaHwVelMaxMgn_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_PullCmpActv_PullCmpActvLrngEnaLatAMaxMgn_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaLatAMaxMgn_Val"


__PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvLrngEnaLatAMaxMgn_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_PullCmpActv_PullCmpActvLrngEnaTiThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaTiThd_Val"


__PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvLrngEnaTiThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_PullCmpActv_PullCmpActvLrngEnaVehSpdMaxMgn_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaVehSpdMaxMgn_Val"


__PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvLrngEnaVehSpdMaxMgn_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_PullCmpActv_PullCmpActvLrngEnaVehSpdMinMgn_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaVehSpdMinMgn_Val"


__PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvLrngEnaVehSpdMinMgn_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_PullCmpActv_PullCmpActvLrngEnaVehSpdRateMaxMgn_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaVehSpdRateMaxMgn_Val"


__PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvLrngEnaVehSpdRateMaxMgn_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_PullCmpActv_PullCmpActvLrngEnaYawRateMaxMgn_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_PullCmpActv_PullCmpActvLrngEnaYawRateMaxMgn_Val"


__PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvLrngEnaYawRateMaxMgn_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_PullCmpActv_PullCmpActvOpstSignTiShoTerm_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_PullCmpActv_PullCmpActvOpstSignTiShoTerm_Val"


__PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvOpstSignTiShoTerm_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_PullCmpActv_PullCmpActvOutpMaxRate_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_PullCmpActv_PullCmpActvOutpMaxRate_Val"


__PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvOutpMaxRate_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_PullCmpActv_PullCmpActvPullCmpShoTermLim_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_PullCmpActv_PullCmpActvPullCmpShoTermLim_Val"


__PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvPullCmpShoTermLim_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_PullCmpActv_PullCmpActvPullCmpTotLim_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_PullCmpActv_PullCmpActvPullCmpTotLim_Val"


__PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvPullCmpTotLim_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_PullCmpActv_PullCmpActvPullErrLimLongTerm_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_PullCmpActv_PullCmpActvPullErrLimLongTerm_Val"


__PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvPullErrLimLongTerm_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_PullCmpActv_PullCmpActvPullErrMgnThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_PullCmpActv_PullCmpActvPullErrMgnThd_Val"


__PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvPullErrMgnThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_PullCmpActv_PullCmpActvPullErrShoTermLim_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_PullCmpActv_PullCmpActvPullErrShoTermLim_Val"


__PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvPullErrShoTermLim_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_PullCmpActv_PullCmpActvShoTermRampTi_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_PullCmpActv_PullCmpActvShoTermRampTi_Val"


__PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvShoTermRampTi_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_PullCmpActv_PullCmpActvYawRateFilFrq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_PullCmpActv_PullCmpActvYawRateFilFrq_Val"


__PST__FLOAT32 Rte_Prm_PullCmpActv_PullCmpActvYawRateFilFrq_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_PullCmpActv_SysGlbPrmSysTqRat_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_PullCmpActv_SysGlbPrmSysTqRat_Val"


__PST__FLOAT32 Rte_Prm_PullCmpActv_SysGlbPrmSysTqRat_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_PullCmpActv_PullCmpActvEna_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_PullCmpActv_PullCmpActvEna_Logl"


__PST__UINT8 Rte_Prm_PullCmpActv_PullCmpActvEna_Logl(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_PullCmpActv_PullCmpActvVehSpdScaTblX_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_PullCmpActv_PullCmpActvVehSpdScaTblX_Ary1D"


__PST__g__44 Rte_Prm_PullCmpActv_PullCmpActvVehSpdScaTblX_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__44 real_random_for_return ;
        __PST__g__44 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_PullCmpActv_PullCmpActvVehSpdScaTblY_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_PullCmpActv_PullCmpActvVehSpdScaTblY_Ary1D"


__PST__g__44 Rte_Prm_PullCmpActv_PullCmpActvVehSpdScaTblY_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__44 real_random_for_return ;
        __PST__g__44 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_IrvWrite_PullCmpActv_PullCmpActvInit1_RampDwnStepSize
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_IrvWrite_PullCmpActv_PullCmpActvInit1_RampDwnStepSize"


__PST__VOID Rte_IrvWrite_PullCmpActv_PullCmpActvInit1_RampDwnStepSize(__PST__FLOAT32 P_0)
{
    /* function is pure */

    return;
}

/*
 * Rte_IrvRead_PullCmpActv_PullCmpActvPer1_RampDwnStepSize
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_IrvRead_PullCmpActv_PullCmpActvPer1_RampDwnStepSize"


__PST__FLOAT32 Rte_IrvRead_PullCmpActv_PullCmpActvPer1_RampDwnStepSize(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * LnrIntrpn_u16_u16VariXu16VariY
 */

#pragma POLYSPACE_POLYMORPHIC "LnrIntrpn_u16_u16VariXu16VariY"


__PST__UINT16 LnrIntrpn_u16_u16VariXu16VariY(__PST__g__44 P_0, __PST__g__44 P_1, __PST__UINT16 P_2, __PST__UINT16 P_3)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}



/*
 * main entry point
 */

void __PST__MAIN__ENTRY__POINT__(void)
{
    { /* call of function main */
        __PST__VOID main(__PST__VOID);        
        
        main();
    }
    
}

