#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}


/* Definition of variables init procedures */


/* Definition of functions */

static void _main_gen_call_GetPullCmpPrm_Oper(void)
{
    extern __PST__VOID GetPullCmpPrm_Oper(__PST__g__16, __PST__g__16, __PST__g__16, __PST__g__17);

    __PST__g__16 __arg__0;
    __PST__g__16 __arg__1;
    __PST__g__16 __arg__2;
    __PST__g__17 __arg__3;
    
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_0[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_1;
        for (_i_main_gen_tmp_1 = 0; _i_main_gen_tmp_1 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_1++)
        {
            _main_gen_tmp_0[_i_main_gen_tmp_1] = _main_gen_init_g10();
        }
        __arg__0 = PST_TRUE() ? 0 : &_main_gen_tmp_0[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_2[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_3;
        for (_i_main_gen_tmp_3 = 0; _i_main_gen_tmp_3 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_3++)
        {
            _main_gen_tmp_2[_i_main_gen_tmp_3] = _main_gen_init_g10();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_2[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_4[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_5;
        for (_i_main_gen_tmp_5 = 0; _i_main_gen_tmp_5 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_5++)
        {
            _main_gen_tmp_4[_i_main_gen_tmp_5] = _main_gen_init_g10();
        }
        __arg__2 = PST_TRUE() ? 0 : &_main_gen_tmp_4[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_6[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_7;
        for (_i_main_gen_tmp_7 = 0; _i_main_gen_tmp_7 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_7++)
        {
            _main_gen_tmp_6[_i_main_gen_tmp_7] = _main_gen_init_g6();
        }
        __arg__3 = PST_TRUE() ? 0 : &_main_gen_tmp_6[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    
    /* call it */
    GetPullCmpPrm_Oper(__arg__0, __arg__1, __arg__2, __arg__3);
}

static void _main_gen_call_SetPullCmpLongTerm_Oper(void)
{
    extern __PST__VOID SetPullCmpLongTerm_Oper(__PST__FLOAT32);

    __PST__FLOAT32 __arg__0;
    
    __arg__0 = _main_gen_init_g10();
    
    /* call it */
    SetPullCmpLongTerm_Oper(__arg__0);
}

static void _main_gen_call_SetPullCmpShoTerm_Oper(void)
{
    extern __PST__VOID SetPullCmpShoTerm_Oper(__PST__FLOAT32);

    __PST__FLOAT32 __arg__0;
    
    __arg__0 = _main_gen_init_g10();
    
    /* call it */
    SetPullCmpShoTerm_Oper(__arg__0);
}


/* Main */

void main(void)
{
    /* Initialization of global variables */

    while (PST_TRUE())
    {
        
        /* Call of functions */

        /* call of function GetPullCmpPrm_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_GetPullCmpPrm_Oper();
        }
        
        /* call of function PullCmpActvInit1 */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID PullCmpActvInit1(__PST__VOID);

            PullCmpActvInit1();
        }
        
        /* call of function PullCmpActvPer1 */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID PullCmpActvPer1(__PST__VOID);

            PullCmpActvPer1();
        }
        
        /* call of function PullCmpActvPer2 */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID PullCmpActvPer2(__PST__VOID);

            PullCmpActvPer2();
        }
        
        /* call of function RstPullCmp_Oper */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID RstPullCmp_Oper(__PST__VOID);

            RstPullCmp_Oper();
        }
        
        /* call of function SetPullCmpLongTerm_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_SetPullCmpLongTerm_Oper();
        }
        
        /* call of function SetPullCmpShoTerm_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_SetPullCmpShoTerm_Oper();
        }
        
    }
}
