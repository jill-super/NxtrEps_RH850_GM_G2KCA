package com.vector.cfg.dom.runtimesys.groovy.api;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.com.IAbstractSignalInstance;
import com.vector.cfg.model.sysdesc.api.com.ICommunicationElement;
import com.vector.cfg.model.sysdesc.api.port.IComponentPort;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IRuntimeSystemApi {

    /**
     * <div class="extdoc" id="selectComponentPorts"><!--Label:IRuntimeSystemApi.selectComponentPorts-->{@link #selectComponentPorts(Closure)} allows the selection of
     * {@link IComponentPort}s using predicates.</div> See {@link ISourceComponentPortSelector} for the available predicates.
     *
     * @param code the predicates for selecting component ports
     * @return the {@link IComponentPortSelection}
     */
    @PublishedMethod
    IComponentPortSelection selectComponentPorts(@Nonnull @VDelegatesToWithClosureParam(ISourceComponentPortSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="selectCommunicationElements"><!--Label:IRuntimeSystemApi.selectCommunicationElements-->{@link #selectCommunicationElements(Closure)} allows the
     * selection of {@link ICommunicationElement}s using predicates.</div> See {@link ICommunicationElementSelector} for the available predicates.
     *
     * @param code the predicates for selecting communication elements
     * @return the {@link ICommunicationElementSelection}
     */
    @PublishedMethod
    ICommunicationElementSelection selectCommunicationElements(@Nonnull @VDelegatesToWithClosureParam(ICommunicationElementSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="selectSignalInstances"><!--Label:IRuntimeSystemApi.selectSignalInstances-->{@link #selectSignalInstances(Closure)} allows the selection of
     * {@link IAbstractSignalInstance}s using predicates.</div> See {@link ISignalInstanceSelector} for the available predicates.
     *
     * @param code the predicates for selecting signal instances
     * @return the {@link ISignalInstanceSelection}
     */
    @PublishedMethod
    ISignalInstanceSelection selectSignalInstances(@Nonnull @VDelegatesToWithClosureParam(ISignalInstanceSelector.class) Closure<?> code);

}
