package com.vector.cfg.gen.core.bswmdmodel.groovy.extensions;

import java.util.List;
import java.util.Optional;

import javax.annotation.Nullable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.scripting.base.services.ActiveProjectContextHolder;
import com.vector.cfg.gen.core.bswmdmodel.GIModelObject;
import com.vector.cfg.gen.core.bswmdmodel.GIOptional;
import com.vector.cfg.gen.core.bswmdmodel.groovy.api.IBswmdModelApiEntryPoint;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.IHasModelObject;
import com.vector.cfg.model.access.ModelAccessUtil;
import com.vector.cfg.model.access.WrappedTypedDefRef;
import com.vector.cfg.model.mdf.IModelObject;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.view.IModelViewExecutionContext;
import com.vector.cfg.model.view.IModelViewManager;
import com.vector.cfg.model.view.config.IModelView;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.scripting.groovy.ClosureCalls;

import groovy.lang.Closure;
import groovy.lang.DelegatesTo;
import groovy.transform.stc.ClosureParams;
import groovy.transform.stc.FirstParam;
import groovy.transform.stc.FromString;

/**
 * This class provides extension methods for BswmdModel object like {@link GIModelObject} and other helper classes like optionals. The bswmdModel methods are the same as in the
 * API interface {@link IBswmdModelApiEntryPoint}.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public final class BswmdModelExtensions {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(BswmdModelExtensions.class);

    private BswmdModelExtensions() {
    }

    /**
     * Returns the bswmd objects found with the specified DefRef, or empty if no elements were found.
     *
     * @param <BSWMD> the bswmd model instance type
     * @param self an definition to search for
     * @return The found object list
     */
    @PublishedMethod
    public static <BSWMD extends GIModelObject> List<BSWMD> bswmdModel(WrappedTypedDefRef<?, ?, ?, BSWMD> self) {
        return bswmdModelApiFromCurrProject().bswmdModel(self);
    }

    /**
     * Calls the closure for each single bswmd object found with the specified {@link DefRef}.
     *
     *
     * @param <BSWMD> the bswmd model instance type
     * @param self an definition to search for
     * @return The found object list
     */
    @PublishedMethod
    public static <BSWMD extends GIModelObject> List<BSWMD> bswmdModel(@DelegatesTo.Target WrappedTypedDefRef<?, ?, ?, BSWMD> self,
            @DelegatesTo(strategy = Closure.DELEGATE_FIRST, genericTypeIndex = 3) @ClosureParams(value = FromString.class, options = "BSWMD") Closure<?> code) {
        return bswmdModelApiFromCurrProject().bswmdModel(self, code);
    }

    /**
     * Returns the found bswmd object from the passed MDF model object.
     *
     *
     * @param <CFG> the MDF model type
     * @param <BSWMD> the bswmd model instance type
     * @param self the MDF model object to use
     * @param defRef an definition of the passed MDF object.
     * @return The found bswmd object
     */
    @PublishedMethod
    public static <CFG extends MIHasDefinition, BSWMD extends GIModelObject> BSWMD bswmdModel(
            CFG self,
            WrappedTypedDefRef<?, CFG, ?, BSWMD> defRef) {
        return bswmdModelApiFromModelObject(self).bswmdModel(self, defRef);
    }

    /**
     * Calls the closure on the found single bswmd object from the passed MDF model object.
     *
     *
     * @param <CFG> the MDF model type
     * @param <BSWMD> the bswmd model instance type
     * @param self the MDF model object to use
     * @param defRef an definition of the passed MDF object.
     * @return The found bswmd object
     */
    @PublishedMethod
    public static <CFG extends MIHasDefinition, BSWMD extends GIModelObject> BSWMD bswmdModel(
            CFG self,
            @DelegatesTo.Target WrappedTypedDefRef<?, CFG, ?, BSWMD> defRef,
            @DelegatesTo(strategy = Closure.DELEGATE_FIRST, genericTypeIndex = 3) @ClosureParams(value = FromString.class, options = "BSWMD") Closure<?> code) {
        return bswmdModelApiFromModelObject(self).bswmdModel(self, defRef, code);
    }

    /**
     * Returns the found bswmd object from the passed {@link IHasModelObject} domain model object.
     * <p>
     * Note: you have to pass the correct DefRef for the domain model object, which is documented at the domain object.
     * </p>
     *
     * @param <CFG> the MDF model type
     * @param <BSWMD> the bswmd model instance type
     * @param self the domain model object to use
     * @param defRef an definition of the passed MDF object.
     * @return The found bswmd object
     */
    @PublishedMethod
    public static <CFG extends MIHasDefinition, BSWMD extends GIModelObject> BSWMD bswmdModel(
            IHasModelObject self,
            WrappedTypedDefRef<?, CFG, ?, BSWMD> defRef) {
        return bswmdModelApiFromModelObject(self.getMdfObject()).bswmdModel(self, defRef);
    }

    /**
     * Calls the closure on the found single bswmd object from the passed {@link IHasModelObject} domain model object.
     *
     * <p>
     * Note: you have to pass the correct DefRef for the domain model object, which is documented at the domain object.
     * </p>
     *
     * @param <CFG> the MDF model type
     * @param <BSWMD> the bswmd model instance type
     * @param self the domain model object to use
     * @param defRef an definition of the passed MDF object.
     * @return The found bswmd object
     */
    @PublishedMethod
    public static <CFG extends MIHasDefinition, BSWMD extends GIModelObject> BSWMD bswmdModel(
            IHasModelObject self,
            @DelegatesTo.Target WrappedTypedDefRef<?, CFG, ?, BSWMD> defRef,
            @DelegatesTo(strategy = Closure.DELEGATE_FIRST, genericTypeIndex = 3) @ClosureParams(value = FromString.class, options = "BSWMD") Closure<?> code) {
        return bswmdModelApiFromModelObject(self.getMdfObject()).bswmdModel(self, defRef);
    }

    private static IBswmdModelApiEntryPoint bswmdModelApiFromCurrProject() {
        final IProjectContext projectContext = ActiveProjectContextHolder.INSTANCE.getCurrentActiveProjectOfThisThreadChecked();
        final IBswmdModelApiEntryPoint apiEntryPoint = projectContext.getInstance(IBswmdModelApiEntryPoint.class);
        return apiEntryPoint;
    }

    private static IBswmdModelApiEntryPoint bswmdModelApiFromModelObject(IModelObject iModelObject) {
        final IProjectContext projectContext = ModelAccessUtil.getProjectContext(iModelObject);
        final IBswmdModelApiEntryPoint apiEntryPoint = projectContext.getInstance(IBswmdModelApiEntryPoint.class);
        return apiEntryPoint;
    }

    /**
     * The method <code>activeViewWith(Closure)}</code> executes the {@link Closure} code under visibility of the {@link GIModelObject#getCreationModelView()} of this
     * {@link GIModelObject}. You could use this method, if you want to return an object from this operation.
     * <p>
     *
     *
     * <pre>
     * <code class="Groovy" id="Execute code with creation IModelView of BswmdModel object">
     * GIModelObject myModelObject = ...;
     *
     * ReturnType returnVal = myModelObject.activeViewWith { theModelObject ->
     *   // do some operations
     *  }
     *
     * </code>
     * </pre>
     *
     * @param <T> the generic type of the BswmdModelObject
     * @param bswmdModelObject the bswmd model object
     * @param code the code to execute
     * @return Returned object of the closure code
     * @see IModelViewManager#executeWithModelView(IModelView)
     */
    @PublishedMethod
    public static <T extends GIModelObject, R> R activeViewWith(@DelegatesTo.Target T bswmdModelObject,
            @DelegatesTo(strategy = Closure.DELEGATE_FIRST) @ClosureParams(FirstParam.class) Closure<R> code) {

        try (IModelViewExecutionContext ctx = bswmdModelObject.executeWithCreationModelView()) {
            return ClosureCalls.callWithDelegateFirst(bswmdModelObject, code);
        }
    }

    /**
     * Converts the {@link GIOptional} to a boolean value <code>true</code>, if the element exists, otherwise <code>false</code>.
     *
     * @param optional the optional to check
     * @return true, if {@link GIOptional#exists()} returns <code>true</code>
     */
    @PublishedMethod
    public static boolean asBoolean(GIOptional<?> optional) {
        if (optional == null) {
            return false;
        }
        return optional.exists();
    }

    /**
     * If a value is present, invoke the specified {@link Closure} with the value, otherwise do nothing.
     *
     * @param <T> the optional reference type
     * @param <R> the return type of the called closure code
     * @param optional to optional to check
     * @param code block to be executed if a value is present
     * @return the return value of the closure, or <code>null</code>, if nothing was executed.
     * @throws NullPointerException if value is present and {@code code} is null
     */
    @Nullable
    @PublishedMethod
    public static <T extends GIModelObject, R> R ifPresent(@DelegatesTo.Target GIOptional<T> optional,
            @DelegatesTo(value = DelegatesTo.Target.class, strategy = Closure.DELEGATE_FIRST, genericTypeIndex = 0) @ClosureParams(FirstParam.FirstGenericType.class) Closure<R> code) {
        if (optional.exists()) {
            return ClosureCalls.callWithDelegateFirst(optional.get(), code);
        }
        return null;
    }

    /**
     * Converts the {@link Optional} to a boolean value <code>true</code>, if the element is present, otherwise <code>false</code>.
     *
     * @param optional the optional to check
     * @return true, if {@link Optional#isPresent()} returns <code>true</code>
     */
    @PublishedMethod
    public static boolean asBoolean(Optional<?> optional) {
        if (optional == null) {
            return false;
        }
        return optional.isPresent();
    }

    /**
     * If a value is present, invoke the specified {@link Closure} with the value, otherwise do nothing.
     *
     * @param <T> the optional reference type
     * @param <R> the return type of the called closure code
     * @param optional to optional to check
     * @param code block to be executed if a value is present
     * @return the return value of the closure, or <code>null</code>, if nothing was executed.
     * @throws NullPointerException if value is present and {@code code} is null
     */
    @Nullable
    @PublishedMethod
    public static <T, R> R ifPresent(@DelegatesTo.Target Optional<T> optional,
            @DelegatesTo(value = DelegatesTo.Target.class, strategy = Closure.DELEGATE_FIRST, genericTypeIndex = 0) @ClosureParams(FirstParam.FirstGenericType.class) Closure<R> code) {
        if (optional.isPresent()) {
            return ClosureCalls.callWithDelegateFirst(optional.get(), code);
        }
        return null;
    }

    /**
     * Converts the {@link com.google.common.base.Optional} to a boolean value <code>true</code>, if the element is present, otherwise <code>false</code>.
     *
     * @param optional the optional to check
     * @return true, if {@link com.google.common.base.Optional#isPresent()} returns <code>true</code>
     */
    @PublishedMethod
    public static boolean asBoolean(com.google.common.base.Optional<?> optional) {
        if (optional == null) {
            return false;
        }
        return optional.isPresent();
    }

    /**
     * If a value is present, invoke the specified {@link Closure} with the value, otherwise do nothing.
     *
     * @param <T> the optional reference type
     * @param <R> the return type of the called closure code
     * @param optional to optional to check
     * @param code block to be executed if a value is present
     * @return the return value of the closure, or <code>null</code>, if nothing was executed.
     * @throws NullPointerException if value is present and {@code code} is null
     */
    @Nullable
    @PublishedMethod
    public static <T, R> R ifPresent(@DelegatesTo.Target com.google.common.base.Optional<T> optional,
            @DelegatesTo(value = DelegatesTo.Target.class, strategy = Closure.DELEGATE_FIRST, genericTypeIndex = 0) @ClosureParams(FirstParam.FirstGenericType.class) Closure<R> code) {
        if (optional.isPresent()) {
            return ClosureCalls.callWithDelegateFirst(optional.get(), code);
        }
        return null;
    }
}
