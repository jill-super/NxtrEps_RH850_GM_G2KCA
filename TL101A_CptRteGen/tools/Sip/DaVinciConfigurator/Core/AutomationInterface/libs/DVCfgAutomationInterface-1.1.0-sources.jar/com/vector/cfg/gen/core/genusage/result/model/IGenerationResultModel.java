package com.vector.cfg.gen.core.genusage.result.model;

import java.util.Date;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.EGenerationProcessResult;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IGenerationResultModel {

    @PublishedMethod
    IGenerationResultRoot getGenerationResultRoot();

    /**
     * Gets the last {@link EGenerationProcessResult}, or <code>null</code> if the process is currently running, or has no last result.
     *
     * @return the result
     */
    @PublishedMethod
    EGenerationProcessResult getResult();

    /**
     * Gets the last execution time, or <code>null</code>, if no ExecutionTime is available.
     *
     * @return the last execution time
     */
    @PublishedMethod
    Date getLastExecutionTime();

    /**
     * Returns the duration in second of the last execution. Or <code>null</code> if there was no execution.
     */
    @PublishedMethod
    Double getLastExecutionDurationInS();

    /**
     * Gets the duration in second of the last execution. Or {@code <none>} if there was no execution.
     *
     * @return the duration in second of the last execution. Or {@code <none>} if there was no execution.
     */
    @PublishedMethod
    String getFormattedDuration();
}
