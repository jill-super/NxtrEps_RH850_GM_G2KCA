package com.vector.cfg.automation.api.userinteraction;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.cfg.util.text.log.IUserInteractionMessageService;

/**
 * {@link IUserInteractionApi} provides API to display messages to the user. Use the {@link IUserInteractionApiEntryPoint} to retrieve an instance of
 * {@link IUserInteractionApi}.
 *
 * <div class="extdoc" id="Common"> The UserInteraction API provides methods to display messages to the user directly. In UI mode the DaVinci Configurator will prompt a message
 * box an will block until the user has acknowledged the message. In console (non UI) mode, the message is logged to the console in a user logger.
 *
 * The user logger will display error, warnings and infos by default. The logger name will not be displayed.
 *
 * The user interaction is good to display information where the user has to respond to immediately. Please use the feature sparingly, because users do not like to acknowledge
 * multiple messages for a single script task execution.
 *
 * The code block <code>userInteractions{}</code> provides the API inside of the block. The following methods can be used:
 * <ul>
 * <li><code>errorToUser()</code></li>
 * <li><code>warnToUser()</code></li>
 * <li><code>infoToUser()</code></li>
 * <li><code>messageToUser(ELogLevel, Object)</code></li>
 * </ul>
 *
 * The severity (error, warning, info) will change the display (icons, text) of the message box. No other semantic is applied by the severity.
 *
 * </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IUserInteractionApi extends IUserInteractionMessageService {

}