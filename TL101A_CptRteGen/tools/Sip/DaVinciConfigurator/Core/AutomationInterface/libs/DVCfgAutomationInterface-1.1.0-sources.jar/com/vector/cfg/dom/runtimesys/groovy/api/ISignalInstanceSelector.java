package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.List;
import java.util.regex.Pattern;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.com.EDirection;
import com.vector.cfg.model.sysdesc.api.com.IAbstractSignalInstance;
import com.vector.cfg.util.scripting.groovy.VClassClosureParams;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * The {@link ISignalInstanceSelector} Api allows the definition of predicates for signal selection.
 * <p>
 * <div class="extdoc" id="ISignalInstanceSelector"> Per default the predicates are combined via logical AND. To realize other combinations, use the 'or','not' and 'and'
 * predicates.</div>
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ISignalInstanceSelector {

    /**
     * <div class="extdoc" id="and">{@link #and(Closure)} combines the predicates inside the closure with a logical AND.</div>
     *
     * @param code Closure containing predicates.
     */
    @PublishedMethod
    void and(@Nonnull @VDelegatesToWithClosureParam(ISignalInstanceSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="or">{@link #or(Closure)} combines the predicates inside the closure with a logical OR.</div>
     *
     * @param code Closure containing predicates.
     */
    @PublishedMethod
    void or(@Nonnull @VDelegatesToWithClosureParam(ISignalInstanceSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="not">{@link #not(Closure)} negates the combination of predicates inside the closure.</div>
     *
     * @param code Closure containing predicates.
     */
    @PublishedMethod
    void not(@Nonnull @VDelegatesToWithClosureParam(ISignalInstanceSelector.class) Closure<?> code);

    // ----------------------------

    /**
     * <div class="extdoc" id="filterAdvanced">{@link #filterAdvanced(Closure)} matches signal instances for which the given closure results to true.</div>
     *
     * @param code The closure to select signal instances.
     */
    @PublishedMethod
    void filterAdvanced(@Nonnull @VClassClosureParams(IAbstractSignalInstance.class) Closure<Boolean> code);

    /**
     * <div class="extdoc" id="unmapped">{@link #unmapped()} matches signal instances which are not data-mapped.</div>
     */
    @PublishedMethod
    void unmapped();

    /**
     * <div class="extdoc" id="mapped">{@link #mapped()} matches signal instances which are data-mapped.</div>
     */
    @PublishedMethod
    void mapped();

    /**
     * <div class="extdoc" id="name">{@link #name(String)} matches signal instances with the given name.</div>
     *
     * @param name A signal instance name.
     */
    @PublishedMethod
    void name(String name);

    /**
     * <div class="extdoc" id="namePattern">{@link #name(Pattern)} matches signal instances with the given name pattern.</div>
     *
     * @param namePattern A signal instance name pattern.
     */
    @PublishedMethod
    void name(Pattern namePattern);

    /**
     * <div class="extdoc" id="asrPath">{@link #asrPath(String)} matches signal instances with the given autosar path.</div>
     *
     * @param asrPath A signal instance autosar path.
     */
    @PublishedMethod
    void asrPath(String asrPath);

    /**
     * <div class="extdoc" id="asrPathPattern">{@link #asrPath(Pattern)} matches signal instances with the given autosar path pattern.</div>
     *
     * @param asrPathPattern A signal instance autosar path pattern.
     */
    @PublishedMethod
    void asrPath(Pattern asrPathPattern);

    /**
     * <div class="extdoc" id="iSignal">{@link #iSignal(String)} matches signal instances which are referenced at least by one ISignal/ISignalGroup with the given name.</div>
     *
     * @param iSignalName An ISignal name.
     */
    @PublishedMethod
    void iSignal(String iSignalName);

    /**
     * <div class="extdoc" id="iSignalPattern">{@link #iSignal(Pattern)} matches signal instances which are referenced at least by one ISignal/ISignalGroup with the given name
     * pattern.</div>
     *
     * @param iSignalNamePattern An ISignal name pattern.
     */
    @PublishedMethod
    void iSignal(Pattern iSignalNamePattern);

    /**
     * <div class="extdoc" id="iSignalAsrPath">{@link #iSignalAsrPath(String)} matches signal instances which are referenced at least by one ISignal/ISignalGroup with the given
     * autosar path.</div>
     *
     * @param iSignalAsrPath An ISignal autosar path.
     */
    @PublishedMethod
    void iSignalAsrPath(String iSignalAsrPath);

    /**
     * <div class="extdoc" id="iSignalAsrPathPattern">{@link #iSignalAsrPath(Pattern)} matches signal instances which are referenced at least by one ISignal/ISignalGroup with
     * the given autosar path pattern.</div>
     *
     * @param iSignalAsrPathPattern An ISignal autosar path pattern.
     */
    @PublishedMethod
    void iSignalAsrPath(Pattern iSignalAsrPathPattern);

    /**
     * <div class="extdoc" id="signalGroup">{@link #signalGroup()} matches signal instances which are a signal group instance.</div>
     */
    @PublishedMethod
    void signalGroup();

    /**
     * <div class="extdoc" id="groupSignal">{@link #groupSignal()} matches signal instances which are a group signal.</div>
     */
    @PublishedMethod
    void groupSignal();

    /**
     * <div class="extdoc" id="transformed">{@link #transformed()} matches signal instances which are transformation signals.</div>
     */
    @PublishedMethod
    void transformed();

    /**
     * <div class="extdoc" id="tx">{@link #tx()} matches signal instances whose direction is compatible to {@link EDirection.Tx}.</div>
     */
    @PublishedMethod
    void tx();

    /**
     * <div class="extdoc" id="rx">{@link #rx()} matches signal instances whose direction is compatible to {@link EDirection.Rx}.</div>
     */
    @PublishedMethod
    void rx();

    // -------------- internal API

    @KeepSecretFromPublishedApi
    List<IAbstractSignalInstance> getSelectedSignalInstances();
}
