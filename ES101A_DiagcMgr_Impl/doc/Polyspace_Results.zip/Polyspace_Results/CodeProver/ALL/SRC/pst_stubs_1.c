#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__SINT16 pst_random_g_3;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct Rte_CDS_DiagcMgrProxyAppl6 _main_gen_init_g107(void);

extern struct __PST__g__20 _main_gen_init_g20(void);

extern struct Rte_CDS_DiagcMgrProxyAppl10 _main_gen_init_g98(void);

extern __PST__SINT16 _main_gen_init_g3(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern struct Rte_CDS_DiagcMgr _main_gen_init_g70(void);

struct Rte_CDS_DiagcMgr _main_gen_init_g70(void)
{
    static struct Rte_CDS_DiagcMgr x;
    /* struct/union type */
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_56[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_57;
        for (_i_main_gen_tmp_57 = 0; _i_main_gen_tmp_57 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_57++)
        {
            _main_gen_tmp_56[_i_main_gen_tmp_57] = _main_gen_init_g6();
        }
        x.Pim_ClrDiagcFlg = PST_TRUE() ? 0 : &_main_gen_tmp_56[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__g__72 _main_gen_tmp_58[ARRAY_NBELEM(__PST__g__72)];
        __PST__UINT32 _i_main_gen_tmp_59;
        for (_i_main_gen_tmp_59 = 0; _i_main_gen_tmp_59 < ARRAY_NBELEM(__PST__g__72); _i_main_gen_tmp_59++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_60_0;
                
                for (_main_gen_tmp_60_0 = 0; _main_gen_tmp_60_0 < 20; _main_gen_tmp_60_0++)
                {
                    /* struct/union type */
                    _main_gen_tmp_58[_i_main_gen_tmp_59][_main_gen_tmp_60_0].NtcNr = _main_gen_init_g7();
                    _main_gen_tmp_58[_i_main_gen_tmp_59][_main_gen_tmp_60_0].AgiCntr = _main_gen_init_g6();
                    _main_gen_tmp_58[_i_main_gen_tmp_59][_main_gen_tmp_60_0].Sts = _main_gen_init_g6();
                }
            }
        }
        x.Pim_DiagcMgrNtcFltAry = PST_TRUE() ? 0 : &_main_gen_tmp_58[ARRAY_NBELEM(__PST__g__72) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_61[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_62;
        for (_i_main_gen_tmp_62 = 0; _i_main_gen_tmp_62 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_62++)
        {
            _main_gen_tmp_61[_i_main_gen_tmp_62] = _main_gen_init_g7();
        }
        x.Pim_DtcEnaSts = PST_TRUE() ? 0 : &_main_gen_tmp_61[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    /* pointer */
    {
        static __PST__g__75 _main_gen_tmp_63[ARRAY_NBELEM(__PST__g__75)];
        __PST__UINT32 _i_main_gen_tmp_64;
        for (_i_main_gen_tmp_64 = 0; _i_main_gen_tmp_64 < ARRAY_NBELEM(__PST__g__75); _i_main_gen_tmp_64++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_65_0;
                
                for (_main_gen_tmp_65_0 = 0; _main_gen_tmp_65_0 < 3; _main_gen_tmp_65_0++)
                {
                    /* base type */
                    _main_gen_tmp_63[_i_main_gen_tmp_64][_main_gen_tmp_65_0] = pst_random_g_6;
                }
            }
        }
        x.Pim_DtcIdxPrevSts = PST_TRUE() ? 0 : &_main_gen_tmp_63[ARRAY_NBELEM(__PST__g__75) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_66[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_67;
        for (_i_main_gen_tmp_67 = 0; _i_main_gen_tmp_67 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_67++)
        {
            _main_gen_tmp_66[_i_main_gen_tmp_67] = _main_gen_init_g6();
        }
        x.Pim_PrevClrDtcFlg = PST_TRUE() ? 0 : &_main_gen_tmp_66[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__g__77 _main_gen_tmp_68[ARRAY_NBELEM(__PST__g__77)];
        __PST__UINT32 _i_main_gen_tmp_69;
        for (_i_main_gen_tmp_69 = 0; _i_main_gen_tmp_69 < ARRAY_NBELEM(__PST__g__77); _i_main_gen_tmp_69++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_70_0;
                
                for (_main_gen_tmp_70_0 = 0; _main_gen_tmp_70_0 < 8; _main_gen_tmp_70_0++)
                {
                    /* struct/union type */
                    _main_gen_tmp_68[_i_main_gen_tmp_69][_main_gen_tmp_70_0].MicroDiagcData = _main_gen_init_g8();
                    _main_gen_tmp_68[_i_main_gen_tmp_69][_main_gen_tmp_70_0].HwTq = _main_gen_init_g3();
                    _main_gen_tmp_68[_i_main_gen_tmp_69][_main_gen_tmp_70_0].MotTq = _main_gen_init_g3();
                    _main_gen_tmp_68[_i_main_gen_tmp_69][_main_gen_tmp_70_0].IgnCntr = _main_gen_init_g8();
                    _main_gen_tmp_68[_i_main_gen_tmp_69][_main_gen_tmp_70_0].BrdgVltg = _main_gen_init_g7();
                    _main_gen_tmp_68[_i_main_gen_tmp_69][_main_gen_tmp_70_0].EcuT = _main_gen_init_g3();
                    _main_gen_tmp_68[_i_main_gen_tmp_69][_main_gen_tmp_70_0].NtcNr = _main_gen_init_g7();
                    _main_gen_tmp_68[_i_main_gen_tmp_69][_main_gen_tmp_70_0].NtcStInfo = _main_gen_init_g6();
                    _main_gen_tmp_68[_i_main_gen_tmp_69][_main_gen_tmp_70_0].SysSt = _main_gen_init_g6();
                    _main_gen_tmp_68[_i_main_gen_tmp_69][_main_gen_tmp_70_0].VehSpd = _main_gen_init_g7();
                }
            }
        }
        x.Pim_SnpshtDataAry = PST_TRUE() ? 0 : &_main_gen_tmp_68[ARRAY_NBELEM(__PST__g__77) / 2];
    }
    return x;
}

struct Rte_CDS_DiagcMgrProxyAppl10 _main_gen_init_g98(void)
{
    static struct Rte_CDS_DiagcMgrProxyAppl10 x;
    /* struct/union type */
    /* pointer */
    {
        static struct __PST__g__20 _main_gen_tmp_73[ARRAY_NBELEM(struct __PST__g__20)];
        __PST__UINT32 _i_main_gen_tmp_74;
        for (_i_main_gen_tmp_74 = 0; _i_main_gen_tmp_74 < ARRAY_NBELEM(struct __PST__g__20); _i_main_gen_tmp_74++)
        {
            _main_gen_tmp_73[_i_main_gen_tmp_74] = _main_gen_init_g20();
        }
        x.Pim_DiagcData10 = PST_TRUE() ? 0 : &_main_gen_tmp_73[ARRAY_NBELEM(struct __PST__g__20) / 2];
    }
    /* pointer */
    {
        static __PST__g__100 _main_gen_tmp_75[ARRAY_NBELEM(__PST__g__100)];
        __PST__UINT32 _i_main_gen_tmp_76;
        for (_i_main_gen_tmp_76 = 0; _i_main_gen_tmp_76 < ARRAY_NBELEM(__PST__g__100); _i_main_gen_tmp_76++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_77_0;
                
                for (_main_gen_tmp_77_0 = 0; _main_gen_tmp_77_0 < 59; _main_gen_tmp_77_0++)
                {
                    /* struct/union type */
                    _main_gen_tmp_75[_i_main_gen_tmp_76][_main_gen_tmp_77_0].NtcStInfo = _main_gen_init_g6();
                    _main_gen_tmp_75[_i_main_gen_tmp_76][_main_gen_tmp_77_0].Sts = _main_gen_init_g6();
                    _main_gen_tmp_75[_i_main_gen_tmp_76][_main_gen_tmp_77_0].AgiCntr = _main_gen_init_g6();
                }
            }
        }
        x.Pim_DiagcMgrNtcInfo10Ary = PST_TRUE() ? 0 : &_main_gen_tmp_75[ARRAY_NBELEM(__PST__g__100) / 2];
    }
    /* pointer */
    {
        static __PST__g__102 _main_gen_tmp_78[ARRAY_NBELEM(__PST__g__102)];
        __PST__UINT32 _i_main_gen_tmp_79;
        for (_i_main_gen_tmp_79 = 0; _i_main_gen_tmp_79 < ARRAY_NBELEM(__PST__g__102); _i_main_gen_tmp_79++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_80_0;
                
                for (_main_gen_tmp_80_0 = 0; _main_gen_tmp_80_0 < 10; _main_gen_tmp_80_0++)
                {
                    /* base type */
                    _main_gen_tmp_78[_i_main_gen_tmp_79][_main_gen_tmp_80_0] = pst_random_g_3;
                }
            }
        }
        x.Pim_DiagcMgrNtcInfo10DebCntrAry = PST_TRUE() ? 0 : &_main_gen_tmp_78[ARRAY_NBELEM(__PST__g__102) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_81[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_82;
        for (_i_main_gen_tmp_82 = 0; _i_main_gen_tmp_82 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_82++)
        {
            _main_gen_tmp_81[_i_main_gen_tmp_82] = _main_gen_init_g6();
        }
        x.Pim_PrevClrNtcFlg10 = PST_TRUE() ? 0 : &_main_gen_tmp_81[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__20 _main_gen_tmp_83[ARRAY_NBELEM(struct __PST__g__20)];
        __PST__UINT32 _i_main_gen_tmp_84;
        for (_i_main_gen_tmp_84 = 0; _i_main_gen_tmp_84 < ARRAY_NBELEM(struct __PST__g__20); _i_main_gen_tmp_84++)
        {
            _main_gen_tmp_83[_i_main_gen_tmp_84] = _main_gen_init_g20();
        }
        x.Pim_ProxySetNtcData10 = PST_TRUE() ? 0 : &_main_gen_tmp_83[ARRAY_NBELEM(struct __PST__g__20) / 2];
    }
    return x;
}

struct Rte_CDS_DiagcMgrProxyAppl6 _main_gen_init_g107(void)
{
    static struct Rte_CDS_DiagcMgrProxyAppl6 x;
    /* struct/union type */
    /* pointer */
    {
        static struct __PST__g__20 _main_gen_tmp_87[ARRAY_NBELEM(struct __PST__g__20)];
        __PST__UINT32 _i_main_gen_tmp_88;
        for (_i_main_gen_tmp_88 = 0; _i_main_gen_tmp_88 < ARRAY_NBELEM(struct __PST__g__20); _i_main_gen_tmp_88++)
        {
            _main_gen_tmp_87[_i_main_gen_tmp_88] = _main_gen_init_g20();
        }
        x.Pim_DiagcData6 = PST_TRUE() ? 0 : &_main_gen_tmp_87[ARRAY_NBELEM(struct __PST__g__20) / 2];
    }
    /* pointer */
    {
        static __PST__g__109 _main_gen_tmp_89[ARRAY_NBELEM(__PST__g__109)];
        __PST__UINT32 _i_main_gen_tmp_90;
        for (_i_main_gen_tmp_90 = 0; _i_main_gen_tmp_90 < ARRAY_NBELEM(__PST__g__109); _i_main_gen_tmp_90++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_91_0;
                
                for (_main_gen_tmp_91_0 = 0; _main_gen_tmp_91_0 < 41; _main_gen_tmp_91_0++)
                {
                    /* struct/union type */
                    _main_gen_tmp_89[_i_main_gen_tmp_90][_main_gen_tmp_91_0].NtcStInfo = _main_gen_init_g6();
                    _main_gen_tmp_89[_i_main_gen_tmp_90][_main_gen_tmp_91_0].Sts = _main_gen_init_g6();
                    _main_gen_tmp_89[_i_main_gen_tmp_90][_main_gen_tmp_91_0].AgiCntr = _main_gen_init_g6();
                }
            }
        }
        x.Pim_DiagcMgrNtcInfo6Ary = PST_TRUE() ? 0 : &_main_gen_tmp_89[ARRAY_NBELEM(__PST__g__109) / 2];
    }
    /* pointer */
    {
        static __PST__g__111 _main_gen_tmp_92[ARRAY_NBELEM(__PST__g__111)];
        __PST__UINT32 _i_main_gen_tmp_93;
        for (_i_main_gen_tmp_93 = 0; _i_main_gen_tmp_93 < ARRAY_NBELEM(__PST__g__111); _i_main_gen_tmp_93++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_94_0;
                
                for (_main_gen_tmp_94_0 = 0; _main_gen_tmp_94_0 < 3; _main_gen_tmp_94_0++)
                {
                    /* base type */
                    _main_gen_tmp_92[_i_main_gen_tmp_93][_main_gen_tmp_94_0] = pst_random_g_3;
                }
            }
        }
        x.Pim_DiagcMgrNtcInfo6DebCntrAry = PST_TRUE() ? 0 : &_main_gen_tmp_92[ARRAY_NBELEM(__PST__g__111) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_95[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_96;
        for (_i_main_gen_tmp_96 = 0; _i_main_gen_tmp_96 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_96++)
        {
            _main_gen_tmp_95[_i_main_gen_tmp_96] = _main_gen_init_g6();
        }
        x.Pim_PrevClrNtcFlg6 = PST_TRUE() ? 0 : &_main_gen_tmp_95[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__20 _main_gen_tmp_97[ARRAY_NBELEM(struct __PST__g__20)];
        __PST__UINT32 _i_main_gen_tmp_98;
        for (_i_main_gen_tmp_98 = 0; _i_main_gen_tmp_98 < ARRAY_NBELEM(struct __PST__g__20); _i_main_gen_tmp_98++)
        {
            _main_gen_tmp_97[_i_main_gen_tmp_98] = _main_gen_init_g20();
        }
        x.Pim_ProxySetNtcData6 = PST_TRUE() ? 0 : &_main_gen_tmp_97[ARRAY_NBELEM(struct __PST__g__20) / 2];
    }
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Rte_Inst_DiagcMgr(void)
{
    extern __PST__g__67 Rte_Inst_DiagcMgr;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_DiagcMgr _main_gen_tmp_54[ARRAY_NBELEM(struct Rte_CDS_DiagcMgr)];
            __PST__UINT32 _i_main_gen_tmp_55;
            for (_i_main_gen_tmp_55 = 0; _i_main_gen_tmp_55 < ARRAY_NBELEM(struct Rte_CDS_DiagcMgr); _i_main_gen_tmp_55++)
            {
                _main_gen_tmp_54[_i_main_gen_tmp_55] = _main_gen_init_g70();
            }
            Rte_Inst_DiagcMgr = PST_TRUE() ? 0 : &_main_gen_tmp_54[ARRAY_NBELEM(struct Rte_CDS_DiagcMgr) / 2];
        }
    }
}

static void _main_gen_init_sym_ELECGLBPRM_IVTRCNT_CNT_U08(void)
{
    extern __PST__UINT8 ELECGLBPRM_IVTRCNT_CNT_U08;
    
    /* initialization with random value */
    {
        ELECGLBPRM_IVTRCNT_CNT_U08 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_Rte_Inst_DiagcMgrProxyAppl10(void)
{
    extern __PST__g__95 Rte_Inst_DiagcMgrProxyAppl10;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_DiagcMgrProxyAppl10 _main_gen_tmp_71[ARRAY_NBELEM(struct Rte_CDS_DiagcMgrProxyAppl10)];
            __PST__UINT32 _i_main_gen_tmp_72;
            for (_i_main_gen_tmp_72 = 0; _i_main_gen_tmp_72 < ARRAY_NBELEM(struct Rte_CDS_DiagcMgrProxyAppl10); _i_main_gen_tmp_72++)
            {
                _main_gen_tmp_71[_i_main_gen_tmp_72] = _main_gen_init_g98();
            }
            Rte_Inst_DiagcMgrProxyAppl10 = PST_TRUE() ? 0 : &_main_gen_tmp_71[ARRAY_NBELEM(struct Rte_CDS_DiagcMgrProxyAppl10) / 2];
        }
    }
}

static void _main_gen_init_sym_Rte_Inst_DiagcMgrProxyAppl6(void)
{
    extern __PST__g__104 Rte_Inst_DiagcMgrProxyAppl6;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_DiagcMgrProxyAppl6 _main_gen_tmp_85[ARRAY_NBELEM(struct Rte_CDS_DiagcMgrProxyAppl6)];
            __PST__UINT32 _i_main_gen_tmp_86;
            for (_i_main_gen_tmp_86 = 0; _i_main_gen_tmp_86 < ARRAY_NBELEM(struct Rte_CDS_DiagcMgrProxyAppl6); _i_main_gen_tmp_86++)
            {
                _main_gen_tmp_85[_i_main_gen_tmp_86] = _main_gen_init_g107();
            }
            Rte_Inst_DiagcMgrProxyAppl6 = PST_TRUE() ? 0 : &_main_gen_tmp_85[ARRAY_NBELEM(struct Rte_CDS_DiagcMgrProxyAppl6) / 2];
        }
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Rte_Inst_DiagcMgr */
    _main_gen_init_sym_Rte_Inst_DiagcMgr();
    
    /* init for variable ELECGLBPRM_IVTRCNT_CNT_U08 */
    _main_gen_init_sym_ELECGLBPRM_IVTRCNT_CNT_U08();
    
    /* init for variable Rte_Inst_DiagcMgrProxyAppl10 */
    _main_gen_init_sym_Rte_Inst_DiagcMgrProxyAppl10();
    
    /* init for variable Rte_Inst_DiagcMgrProxyAppl6 */
    _main_gen_init_sym_Rte_Inst_DiagcMgrProxyAppl6();
    
}
